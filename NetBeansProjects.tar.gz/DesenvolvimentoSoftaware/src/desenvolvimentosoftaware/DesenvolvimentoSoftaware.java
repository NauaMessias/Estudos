/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package desenvolvimentosoftaware;

import javax.swing.JOptionPane;

/**
 *
 * @author naua
 */
public class DesenvolvimentoSoftaware {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         cadrastroClliente cc = new cadrastroClliente();
         cc.setVisible(true);
        
     
    }
}


 